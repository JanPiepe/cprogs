/*Variablen und Datentypen 5 --- ASCII Code und Zahlensysteme */

#include <stdio.h>

int main(void)
{

char buchstabe = 'a';

printf("\n Der Buchstabe %c als ASCII-Zeichen\n", buchstabe);
printf("\n Der Buchstabe %i als Dezimal-Zahl\n", buchstabe);
printf("\n Der Buchstabe %x als Hexadezimalzahl\n", buchstabe);
printf("\n Der Buchstabe %o als Oktalzahl\n", buchstabe);

return 0;

}